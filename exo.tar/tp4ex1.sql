SHOW ERRORS;
SET SERVEROUTPUT ON;
CREATE OR REPLACE TRIGGER nouveau_malade 
BEFORE
INSERT 
ON deTAPPIE_malade 
FOR EACH ROW
DECLARE 
	maxi_id Number;
BEGIN 	
	SELECT max(n_malade) INTO maxi_id FROM deTAPPIE_malade;
	maxi_id:=maxi_id+1;
	:NEW.n_malade:=maxi_id;
	:NEW.nom_malade:=LOWER(:NEW.nom_malade);
	:NEW.prenom_malade:=LOWER(:NEW.prenom_malade);
END;
/