
CREATE OR REPLACE PROCEDURE augmenter
IS
BEGIN

	UPDATE deTAPPIE_medecin
	SET salaire=salaire+salaire*0.08
	WHERE  statut='PUPH';

	UPDATE deTAPPIE_medecin
	SET salaire=salaire+salaire*0.05
	WHERE statut='PATT';

	UPDATE deTAPPIE_medecin
	SET salaire=salaire+salaire*0.02
	WHERE statut<>'PUPH' AND statut<>'PATT' ;

END;
/ 
BEGIN
augmenter;
END;
/
