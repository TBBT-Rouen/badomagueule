SHOW ERRORS;
SET SERVEROUTPUT ON;
DROP TABLE intervenants;
CREATE OR REPLACE TYPE qualif_type AS OBJECT
	(qualification varchar(80),
	 tarif number);
/
CREATE TABLE intervenants(matricule number,nom varchar(80),prenom varchar(80),Qualif_type qualif_type,CONSTRAINT mat_pk PRIMARY KEY (matricule));
INSERT INTO intervenants VALUES (2516,'Dupont','Pierre',qualif_type('Developeur',500));
INSERT INTO intervenants VALUES (7655,'Henri','Jacques',qualif_type('Consultant',990.90));
INSERT INTO intervenants VALUES (7687,'Triolet','Elsa',qualif_type('Consultant',1029.00));
DROP TYPE qualif_type;
DESCRIBE intervenants;
SELECT matricule,nom FROM intervenants inter WHERE inter.qualif_type.qualification='Consultant';
SELECT inter.*,inter.qualif_type.tarif-1000 FROM intervenants inter WHERE inter.qualif_type.tarif>1000;
select * FROM intervenants;
