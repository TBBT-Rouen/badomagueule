SHOW ERRORS;
SET SERVEROUTPUT ON;
CREATE OR REPLACE TRIGGER supprimer_consultation
BEFORE
DELETE 
ON deTAPPIE_consultation
FOR EACH ROW
WHEN (OLD.date_consult<SYSDATE)
BEGIN 	
	INSERT INTO deTAPPIE_ARCHIVE_CONSULTATION(n_med,n_malade,date_consult,h_consult) values(:OLD.n_med,:OLD.n_malade,:OLD.date_consult,:OLD.h_consult);
END;
/