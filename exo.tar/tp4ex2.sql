SHOW ERRORS;
SET SERVEROUTPUT ON;
CREATE OR REPLACE TRIGGER nouvelle_consultation
BEFORE
INSERT 
ON deTAPPIE_consultation 
FOR EACH ROW
BEGIN 	
	IF :NEW.prescription IS NULL AND :NEW.examen IS NULL THEN
		:NEW.examen:='Visite de routine';
	END IF;
END;
/