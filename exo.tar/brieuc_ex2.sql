SHOW ERRORS;
SET SERVEROUTPUT ON;
DECLARE
   i number;
BEGIN
   DELETE FROM deTAPPIE_medecin
   WHERE statut LIKE 'PATTASS' AND prof_serv LIKE 'Florence ROUSSEAU';
   i := sql%rowcount;
   IF (i!=0) THEN 
      DBMS_OUTPUT.put_line('SUPPRESSION DE :' || i || ' LIGNE');
   ELSE 
      DBMS_OUTPUT.put_line('AUCUNE SUPPRESSION');
   END IF;
   COMMIT;
END;
/