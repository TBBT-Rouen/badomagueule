
DROP TABLE mission;
DROP TABLE intervenants;
DROP TYPE mission_type;
DROP TYPE intervenant_type;
CREATE OR REPLACE TYPE intervenant_type AS OBJECT
	(mat number,
	nom varchar(80),
	prenom varchar(80),
	tarifApplique float,
	qualification varchar(80));
/
CREATE OR REPLACE TYPE mission_type AS OBJECT
        (code varchar(81),
        intitule varchar(80),
        nbJours number,
        ref REF intervenant_type);
/

create table mission OF mission_type
(constraint PKMission primary key (Code));
create table intervenants OF intervenant_type
(constraint PKIntervenant primary key (Mat));
INSERT INTO intervenants VALUES (2516,'Dupont','Pierre',550,'petit');
INSERT INTO intervenants VALUES (7655,'Henri','Jacques',990.90,'moyen');
INSERT INTO intervenants VALUES (7687,'Triolet','Elsa',1029.00,'gros');
INSERT INTO mission VALUES ('Varalpain033','Etude technique du passage de PEL en CEL',54,(SELECT REF(i) from intervenants i where i.mat=7655));
INSERT INTO mission VALUES ('Armoni002','Prise de contact avec le Directeur',2,(SELECT REF(i) from intervenants i where i.mat=1000));
INSERT INTO intervenants VALUES (1000,'Michelin','Philippe',3000,'dirlo');
UPDATE mission SET ref=(SELECT REF(i) from intervenants i where i.mat=1000) where code='Armoni002';
DESCRIBE mission;
SELECT * FROM mission;
SELECT M.CODE, nbJours*M.ref.tarifApplique AS COUT FROM MISSION M;
UPDATE MISSION SET NBJOURS = NBJOURS + 1;
