SHOW ERRORS;
SET SERVEROUTPUT ON;
CREATE OR REPLACE FUNCTION nbconsultation(id number, m  number, a  number) 
	RETURN number
	IS nbcons number;

	BEGIN
		select count(*) into nbcons from deTAPPIE_consultation 
		where n_med=id and a=extract (year from date_consult)  and m=extract (month from date_consult);
		RETURN nbcons;
END; 
/
DECLARE
	   idmed number;
	   mois number;
	   annee number;

BEGIN
		idmed := &id_medecin;
		mois := &mois;
		annee := &annee;
		dbms_output.put_line(nbconsultation(idmed, mois,annee));

END;
/
