SHOW ERRORS;
SET SERVEROUTPUT ON;
DROP TABLE intervenants;
CREATE OR REPLACE TYPE qualif_type AS OBJECT
	(qualification varchar(80),
	 tarif number);
/
CREATE TABLE intervenants OF qualif_type;
INSERT INTO intervenants VALUES  ('Developeur',500);
INSERT INTO intervenants VALUES  ('Analyste',700);
INSERT INTO intervenants VALUES  ('Chef de projet',900);
INSERT INTO intervenants VALUES  ('Consultant',1000);
INSERT INTO intervenants VALUES  ('Directeur commercial',1300);
UPDATE intervenants SET tarif=tarif*1.025;
SELECT * FROM intervenants ORDER BY qualification;
SELECT AVG(tarif) FROM intervenants;


