SHOW ERRORS;
SET SERVEROUTPUT ON;
DROP TABLE intervenants;
CREATE OR REPLACE TYPE qualif_type AS OBJECT
	(qualification varchar(80),
	 tarif number);
/
CREATE TABLE intervenants(Qualif_type qualif_type);
INSERT INTO intervenants VALUES (qualif_type('Developeur',500));
INSERT INTO intervenants VALUES (qualif_type('Analyste',700));
INSERT INTO intervenants VALUES (qualif_type('Chef de projet',900));
INSERT INTO intervenants VALUES (qualif_type('Consultant',1000));
INSERT INTO intervenants VALUES (qualif_type('Directeur commercial',1300));
UPDATE intervenants interv SET interv.qualif_type.tarif=interv.qualif_type.tarif*1.1;
SELECT * FROM intervenants ORDER BY qualif_type.qualification;
SELECT MAX(inter.qualif_type.tarif) FROM intervenants inter;
SELECT MIN(inter.qualif_type.tarif) FROM intervenants inter;

